# Trading Bot with FastAPI, Supabase & Telegram Bot

## Requirements:

- Docker
- Supabase account
- Telegram Bot Token and Chat ID

## How to set up:

1. Fill in your credentials in `app/main.py`.
2. Build the Docker image:

